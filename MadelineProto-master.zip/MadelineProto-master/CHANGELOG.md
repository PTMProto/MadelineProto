# Changelog


MadelineProto can now be proxied.  

Added `$no_updates` parameter to the deserialize method of `\danog\MadelineProto\Serialization`.


## 1.3.1 Release

Just check the release changelog :D
